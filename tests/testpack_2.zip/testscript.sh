#! /bin/bash

echo "Test script started (don't care about errors)"
mkdir word char
numb=50
echo "100 ---------------------------------------------"
mkdir word/100 char/100
sleep 0.01
for i in $(eval echo {1..$numb}); do
java -jar nothing.jar charcount word_100MB.txt char/100/nothing.txt
rm Result/*
sleep 0.01
java -jar timeout_nowrite.jar charcount word_100MB.txt char/100/timeout_nowrite.txt
rm Result/*
sleep 0.01
java -jar write_no_timeout.jar charcount word_100MB.txt char/100/write_no_timeout.txt
rm Result/*
sleep 0.01
java -jar normal.jar charcount word_100MB.txt char/100/normal.txt
rm Result/*
sleep 0.01

done
echo "---------------------------------------------"
sleep 0.01
for i in $(eval echo {1..$numb}); do
java -jar nothing.jar wordcount word_100MB.txt word/100/nothing.txt
rm Result/*
sleep 0.01
java -jar timeout_nowrite.jar wordcount word_100MB.txt word/100/timeout_nowrite.txt
rm Result/*
sleep 0.01
java -jar write_no_timeout.jar wordcount word_100MB.txt word/100/write_no_timeout.txt
rm Result/*
sleep 0.01
java -jar normal.jar wordcount word_100MB.txt word/100/normal.txt
rm Result/*
sleep 0.01

done

echo "50 ---------------------------------------------"
mkdir word/50 char/50
sleep 0.01
for i in $(eval echo {1..$numb}); do
java -jar normal.jar charcount words50.txt char/50/normal.txt
rm Result/*
sleep 0.01
java -jar nothing.jar charcount words50.txt char/50/nothing.txt
rm Result/*
sleep 0.01
java -jar timeout_nowrite.jar charcount words50.txt char/50/timeout_nowrite.txt
rm Result/*
sleep 0.01
java -jar write_no_timeout.jar charcount words50.txt char/50/write_no_timeout.txt
rm Result/*
sleep 0.01

done
echo "---------------------------------------------"
sleep 0.01
for i in $(eval echo {1..$numb}); do
java -jar normal.jar wordcount words50.txt word/50/normal.txt
rm Result/*
sleep 0.01
java -jar nothing.jar wordcount words50.txt word/50/nothing.txt
rm Result/*
sleep 0.01
java -jar timeout_nowrite.jar wordcount words50.txt word/50/timeout_nowrite.txt
rm Result/*
sleep 0.01
java -jar write_no_timeout.jar wordcount words50.txt word/50/write_no_timeout.txt
rm Result/*
sleep 0.01

done

echo "10 ---------------------------------------------"
mkdir word/10 char/10
sleep 0.01
for i in $(eval echo {1..$numb}); do
java -jar normal.jar charcount word_10MB.txt char/10/normal.txt
rm Result/*
sleep 0.01
java -jar nothing.jar charcount word_10MB.txt char/10/nothing.txt
rm Result/*
sleep 0.01
java -jar timeout_nowrite.jar charcount word_10MB.txt char/10/timeout_nowrite.txt
rm Result/*
sleep 0.01
java -jar write_no_timeout.jar charcount word_10MB.txt char/10/write_no_timeout.txt
rm Result/*
sleep 0.01

done
echo "---------------------------------------------"
sleep 0.01
for i in $(eval echo {1..$numb}); do
java -jar normal.jar wordcount word_10MB.txt word/10/normal.txt
rm Result/*
sleep 0.01
java -jar nothing.jar wordcount word_10MB.txt word/10/nothing.txt
rm Result/*
sleep 0.01
java -jar timeout_nowrite.jar wordcount word_10MB.txt word/10/timeout_nowrite.txt
rm Result/*
sleep 0.01
java -jar write_no_timeout.jar wordcount word_10MB.txt word/10/write_no_timeout.txt
rm Result/*
sleep 0.01

done



echo " red ---------------------------------------------"
for i in $(eval echo {1..10}); do
java -jar redundant-10-80.jar charcount word_100MB.txt char/redundant-10-80.txt
rm Result/*
sleep 0.01
java -jar redundant-10-80map.jar charcount word_100MB.txt char/redundant-10-80map.txt
rm Result/*
sleep 0.01
java -jar redundant-10-80reduce.jar charcount word_100MB.txt char/redundant-10-80reduce.txt
rm Result/*
sleep 0.01
java -jar redundant-10-80.jar wordcount word_100MB.txt word/redundant-10-80.txt
rm Result/*
sleep 0.01
java -jar redundant-10-80map.jar wordcount word_100MB.txt word/redundant-10-80map.txt
rm Result/*
sleep 0.01
java -jar redundant-10-80reduce.jar wordcount word_100MB.txt word/redundant-10-80reduce.txt
rm Result/*
sleep 0.01
done


echo "---------------------------------------------"
echo "script finished"
